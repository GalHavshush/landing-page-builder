This folder is a complete static website. There is nothing to install.

- Open index.html in a browser to preview it locally.
- To publish, upload the contents of this folder to any static host
  (Cloudflare Pages, Netlify, GitHub Pages, S3, your own web server...).
- export.json (and posts.json, if you have a blog) is the editable source of the site;
  keep them to re-import the site later.
